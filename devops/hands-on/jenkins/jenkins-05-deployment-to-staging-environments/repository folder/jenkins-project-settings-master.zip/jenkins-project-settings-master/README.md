# jenkins-project-settings
Jenkins project settings
